@extends('admin.layout')

@section('title', 'Catalogs')

@section('content')

{{-- Page Header --}}
<div class="d-flex justify-content-between align-items-center mb-3">

    <div>
        <h2 class="fw-bold mb-1">Catalogs</h2>
        <p class="text-muted mb-0">
            Manage your honey product catalogs.
        </p>
    </div>

    <a href="{{ route('admin.catalogs.create') }}"
       class="btn btn-primary">
        + Add Catalog
    </a>

</div>


{{-- Catalogs Table --}}
<div class="card border-0 shadow-sm">

    <div class="card-body p-0">

        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">
                    <tr>
                        <th class="px-4">Name</th>
                        <th>Description</th>
                        <th>Products</th>
                        <th class="text-end px-4">Actions</th>
                    </tr>
                </thead>

                <tbody>

                    @forelse ($catalogs as $catalog)

                        <tr>

                            {{-- Name --}}
                            <td class="px-4">
                                <div class="d-flex align-items-center">

                                    <div class="bg-warning bg-opacity-10 rounded-3 p-2 me-3">
                                        <span>🍯</span>
                                    </div>

                                    <div>
                                        <div class="fw-semibold">
                                            {{ $catalog->name }}
                                        </div>

                                        <small class="text-muted">
                                            Catalog #{{ $catalog->id }}
                                        </small>
                                    </div>

                                </div>
                            </td>


                            {{-- Description --}}
                            <td>
                                <span class="text-muted">
                                    {{ Str::limit($catalog->description, 60) }}
                                </span>
                            </td>


                            {{-- Products count --}}
                            <td>

                                <span class="badge bg-light text-dark border">
                                    {{ $catalog->products_count }}
                                    {{ $catalog->products_count == 1 ? 'product' : 'products' }}
                                </span>

                            </td>


                            {{-- Actions --}}
                            <td class="text-end px-4">

                                {{-- Edit --}}
                                <a href="{{ route('admin.catalogs.edit', $catalog) }}"
                                   class="btn btn-outline-primary btn-sm">
                                    Edit
                                </a>


                                {{-- Delete --}}
                                @if (auth()->user()->role === 'admin')

                                    <button
                                        type="button"
                                        class="btn btn-danger btn-sm"
                                        data-bs-toggle="modal"
                                        data-bs-target="#deleteCatalogModal{{ $catalog->id }}"
                                    >
                                        Delete
                                    </button>


                                    {{-- Delete Confirmation Modal --}}
                                    <div
                                        class="modal fade"
                                        id="deleteCatalogModal{{ $catalog->id }}"
                                        tabindex="-1"
                                        aria-labelledby="deleteCatalogModalLabel{{ $catalog->id }}"
                                        aria-hidden="true"
                                    >

                                        <div class="modal-dialog modal-dialog-centered">

                                            <div class="modal-content">

                                                {{-- Modal Header --}}
                                                <div class="modal-header">

                                                    <h5
                                                        class="modal-title"
                                                        id="deleteCatalogModalLabel{{ $catalog->id }}"
                                                    >
                                                        Confirm Catalog Deletion
                                                    </h5>

                                                    <button
                                                        type="button"
                                                        class="btn-close"
                                                        data-bs-dismiss="modal"
                                                        aria-label="Close"
                                                    ></button>

                                                </div>


                                                {{-- Modal Body --}}
                                                <div class="modal-body text-start">

                                                    <p class="mb-2">
                                                        Are you sure you want to delete
                                                        <strong>{{ $catalog->name }}</strong>?
                                                    </p>

                                                    <div class="alert alert-warning mb-0">

                                                        <strong>⚠️ Please note:</strong>

                                                        <br>

                                                        The products inside this catalog
                                                        will <strong>not</strong> be deleted.
                                                        They will simply become unassigned
                                                        from this catalog.

                                                    </div>

                                                </div>


                                                {{-- Modal Footer --}}
                                                <div class="modal-footer">

                                                    <button
                                                        type="button"
                                                        class="btn btn-secondary"
                                                        data-bs-dismiss="modal"
                                                    >
                                                        Cancel
                                                    </button>


                                                    <form
                                                        action="{{ route('admin.catalogs.destroy', $catalog) }}"
                                                        method="POST"
                                                        class="d-inline"
                                                    >

                                                        @csrf
                                                        @method('DELETE')

                                                        <button
                                                            type="submit"
                                                            class="btn btn-danger"
                                                        >
                                                            Yes, Delete Catalog
                                                        </button>

                                                    </form>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                @endif

                            </td>

                        </tr>

                    @empty

                        <tr>
                            <td colspan="4" class="text-center py-5">

                                <div class="text-muted">

                                    <div style="font-size: 2.5rem;">
                                        🍯
                                    </div>

                                    <p class="mb-1 fw-semibold">
                                        No catalogs yet
                                    </p>

                                    <small>
                                        Create your first catalog to organize your products.
                                    </small>

                                </div>

                            </td>
                        </tr>

                    @endforelse

                </tbody>

            </table>

        </div>

    </div>

</div>

@endsection
