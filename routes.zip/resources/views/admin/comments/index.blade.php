@extends('admin.layout')

@section('title', 'Comments & Feedback')

@section('content')


{{-- Feature disabled warning --}}
@unless (\App\Models\Feature::enabled('comments'))
<div class="alert alert-secondary">
    The Comments & Feedback feature is currently <strong>disabled</strong>.
    Customers can't leave new feedback, but you can still review and remove
    existing comments below.

    <a href="{{ route('admin.settings.index') }}">
        Go to Settings
    </a>
</div>
@endunless


{{-- Page Header --}}
<div class="d-flex justify-content-between align-items-center mb-3">

    <div>
        <h2 class="fw-bold mb-1">
            Comments & Feedback
        </h2>

        <p class="text-muted mb-0">
            Review customer feedback and ratings.
        </p>
    </div>

</div>


{{-- Comments Table --}}
<div class="card border-0 shadow-sm">

    <div class="card-body p-0">

        <div class="table-responsive">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">

                    <tr>
                        <th class="px-4">Product</th>
                        <th>Customer</th>
                        <th>Rating</th>
                        <th>Comment</th>
                        <th>Date</th>
                        <th class="text-end px-4">Actions</th>
                    </tr>

                </thead>


                <tbody>

                    @forelse ($comments as $comment)

                    <tr>

                        {{-- Product --}}
                        <td class="px-4">

                            <div class="fw-semibold">
                                {{ $comment->product->name ?? 'Deleted product' }}
                            </div>

                            @if ($comment->product)
                            <small class="text-muted">
                                Product #{{ $comment->product->id }}
                            </small>
                            @endif

                        </td>


                        {{-- Customer --}}
                        <td>

                            <div class="fw-semibold">
                                {{ $comment->user->name ?? 'Deleted user' }}
                            </div>

                            @if ($comment->user)
                            <small class="text-muted">
                                {{ $comment->user->email }}
                            </small>
                            @endif

                        </td>


                        {{-- Rating --}}
                        <td>

                            @if ($comment->rating)

                            <span class="text-warning">
                                {{ str_repeat('★', $comment->rating) }}{{ str_repeat('☆', 5 - $comment->rating) }}
                            </span>

                            @else

                            <span class="text-muted">
                                —
                            </span>

                            @endif

                        </td>


                        {{-- Comment --}}
                        <td>

                            <span class="text-muted">
                                {{ \Illuminate\Support\Str::limit($comment->body, 60) }}
                            </span>

                        </td>


                        {{-- Date --}}
                        <td>

                            <span class="text-muted">
                                {{ $comment->created_at->format('M d, Y') }}
                            </span>

                        </td>


                        {{-- Actions --}}
                        <td class="text-end px-4">

                            {{-- Delete button --}}
                            <button
                                type="button"
                                class="btn btn-danger btn-sm"
                                data-bs-toggle="modal"
                                data-bs-target="#deleteCommentModal{{ $comment->id }}">
                                Delete
                            </button>


                            {{-- Delete Confirmation Modal --}}
                            <div
                                class="modal fade"
                                id="deleteCommentModal{{ $comment->id }}"
                                tabindex="-1"
                                aria-labelledby="deleteCommentModalLabel{{ $comment->id }}"
                                aria-hidden="true">

                                <div class="modal-dialog modal-dialog-centered">

                                    <div class="modal-content">

                                        {{-- Modal Header --}}
                                        <div class="modal-header">

                                            <h5
                                                class="modal-title"
                                                id="deleteCommentModalLabel{{ $comment->id }}">
                                                Confirm Comment Deletion
                                            </h5>

                                            <button
                                                type="button"
                                                class="btn-close"
                                                data-bs-dismiss="modal"
                                                aria-label="Close"></button>

                                        </div>


                                        {{-- Modal Body --}}
                                        <div class="modal-body text-start">

                                            <p class="mb-2">
                                                Are you sure you want to delete this comment?
                                            </p>

                                            <div class="border rounded p-3 bg-light">

                                                @if ($comment->rating)

                                                <div class="mb-2">
                                                    <span class="text-warning">
                                                        {{ str_repeat('★', $comment->rating) }}{{ str_repeat('☆', 5 - $comment->rating) }}
                                                    </span>
                                                </div>

                                                @endif

                                                <p class="mb-1">
                                                    "{{ $comment->body }}"
                                                </p>

                                                <small class="text-muted">
                                                    By {{ $comment->user->name ?? 'Deleted user' }}
                                                </small>

                                            </div>

                                            <div class="alert alert-warning mt-3 mb-0">

                                                <strong>⚠️ Please note:</strong>

                                                <br>

                                                This comment will be permanently deleted.
                                                This action cannot be undone.

                                            </div>

                                        </div>


                                        {{-- Modal Footer --}}
                                        <div class="modal-footer">

                                            <button
                                                type="button"
                                                class="btn btn-secondary"
                                                data-bs-dismiss="modal">
                                                Cancel
                                            </button>


                                            <form
                                                action="{{ route('admin.comments.destroy', $comment) }}"
                                                method="POST"
                                                class="d-inline">

                                                @csrf
                                                @method('DELETE')

                                                <button
                                                    type="submit"
                                                    class="btn btn-danger">
                                                    Yes, Delete Comment
                                                </button>

                                            </form>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </td>

                    </tr>

                    @empty

                    <tr>

                        <td colspan="6" class="text-center py-5">

                            <div class="text-muted">

                                <div style="font-size: 2.5rem;">
                                    💬
                                </div>

                                <p class="mb-1 fw-semibold">
                                    No comments yet
                                </p>

                                <small>
                                    Customer feedback will appear here.
                                </small>

                            </div>

                        </td>

                    </tr>

                    @endforelse

                </tbody>

            </table>

        </div>

    </div>

</div>


{{-- Pagination --}}
<div class="mt-3">
    {{ $comments->links() }}
</div>


@endsection